Twitter Bootstrap CSS framwork from Bootstrap was used in this website

same with Express Generator everything is orginized in a simple and easy to follow structure 